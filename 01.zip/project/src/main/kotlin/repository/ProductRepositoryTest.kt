package com.example.repository

import com.example.model.ProductRequest
import org.testng.annotations.BeforeTest
import org.testng.annotations.Test
import kotlin.test.*

class ProductRepositoryTest {

    @BeforeTest
    fun setup() {
        ProductRepository.getAll().clear() // ทำให้ล้าง state ได้
    }

    @Test
    fun testAddProduct() {
        val request = ProductRequest("Test", "Test product", 9.99, 5, 1)
        val product = ProductRepository.add(request)
        assertEquals("Test", product.name)
        assertEquals(5, product.stockQuantity)
    }

    @Test
    fun testReduceStockSuccess() {
        val request = ProductRequest("Test", "Desc", 10.0, 10, 1)
        val product = ProductRepository.add(request)
        val result = ProductRepository.reduceStock(product.id, 5)
        assertTrue(result)
        assertEquals(5, ProductRepository.getById(product.id)?.stockQuantity)
    }

    @Test
    fun testReduceStockFail() {
        val request = ProductRequest("Test", "Desc", 10.0, 3, 1)
        val product = ProductRepository.add(request)
        val result = ProductRepository.reduceStock(product.id, 5)
        assertFalse(result)
    }
}
