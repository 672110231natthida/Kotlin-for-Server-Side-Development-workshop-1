package com.example

import com.example.routes.*
import io.ktor.application.*
import io.ktor.features.ContentNegotiation
import io.ktor.routing.*
import io.ktor.serialization.json.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*

fun main() {
    embeddedServer(Netty, port = 8080) {
        module()
    }.start(wait = true)
}

fun Application.module() {
    install(ContentNegotiation) {
        json()
    }

    routing {
        categoryRoutes()
        productRoutes()
    }
}
