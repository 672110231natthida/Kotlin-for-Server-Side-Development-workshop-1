package com.example.routes

import com.example.model.*
import com.example.repository.*
import io.ktor.server.application.*
import io.ktor.server.routing.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.http.*

fun Route.productRoutes() {
    route("/products") {
        get {
            call.respond(ProductRepository.getAll())
        }

        get("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            val product = id?.let { ProductRepository.getById(it) }
            if (product != null) call.respond(product)
            else call.respond(HttpStatusCode.NotFound)
        }

        post {
            val req = call.receive<ProductRequest>()
            if (CategoryRepository.getById(req.categoryId) == null)
                call.respond(HttpStatusCode.BadRequest, "Invalid categoryId")
            else
                call.respond(HttpStatusCode.Created, ProductRepository.add(req))
        }

        put("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            val req = call.receive<ProductRequest>()
            if (id != null && ProductRepository.update(id, req)) call.respond(HttpStatusCode.OK)
            else call.respond(HttpStatusCode.NotFound)
        }

        delete("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id != null && ProductRepository.delete(id)) call.respond(HttpStatusCode.NoContent)
            else call.respond(HttpStatusCode.NotFound)
        }

        post("{id}/add-stock") {
            val id = call.parameters["id"]?.toIntOrNull()
            val amount = call.request.queryParameters["amount"]?.toIntOrNull()
            if (id != null && amount != null && ProductRepository.addStock(id, amount))
                call.respond(HttpStatusCode.OK)
            else
                call.respond(HttpStatusCode.BadRequest, "Invalid ID or amount")
        }

        post("{id}/reduce-stock") {
            val id = call.parameters["id"]?.toIntOrNull()
            val amount = call.request.queryParameters["amount"]?.toIntOrNull()
            if (id != null && amount != null && ProductRepository.reduceStock(id, amount))
                call.respond(HttpStatusCode.OK)
            else
                call.respond(HttpStatusCode.BadRequest, "Not enough stock or invalid ID")
        }
    }
}
