package com.example.routes

import com.example.model.*
import com.example.repository.CategoryRepository
import io.ktor.server.application.*
import io.ktor.server.routing.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.http.*

fun Route.categoryRoutes() {
    route("/categories") {
        get {
            call.respond(CategoryRepository.getAll())
        }

        get("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            val category = id?.let { CategoryRepository.getById(it) }
            if (category != null) call.respond(category)
            else call.respond(HttpStatusCode.NotFound)
        }

        post {
            val req = call.receive<CategoryRequest>()
            call.respond(HttpStatusCode.Created, CategoryRepository.add(req))
        }

        put("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            val req = call.receive<CategoryRequest>()
            if (id != null && CategoryRepository.update(id, req)) call.respond(HttpStatusCode.OK)
            else call.respond(HttpStatusCode.NotFound)
        }

        delete("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id != null && CategoryRepository.delete(id)) call.respond(HttpStatusCode.NoContent)
            else call.respond(HttpStatusCode.NotFound)
        }
    }
}
