package com.example.repository

import com.example.model.*

object ProductRepository {
    private val products = mutableListOf<Product>()
    private var nextId = 1

    fun getAll() = products
    fun getById(id: Int) = products.find { it.id == id }

    fun add(request: ProductRequest): Product {
        val product = Product(nextId++, request.name, request.description, request.price, request.stockQuantity, request.categoryId)
        products.add(product)
        return product
    }

    fun update(id: Int, request: ProductRequest): Boolean {
        val index = products.indexOfFirst { it.id == id }
        return if (index != -1) {
            products[index] = Product(id, request.name, request.description, request.price, request.stockQuantity, request.categoryId)
            true
        } else false
    }

    fun delete(id: Int): Boolean = products.removeIf { it.id == id }

    fun addStock(id: Int, amount: Int): Boolean {
        val product = getById(id)
        return if (product != null && amount > 0) {
            product.stockQuantity += amount
            true
        } else false
    }

    fun reduceStock(id: Int, amount: Int): Boolean {
        val product = getById(id)
        return if (product != null && product.stockQuantity >= amount) {
            product.stockQuantity -= amount
            true
        } else false
    }
}
