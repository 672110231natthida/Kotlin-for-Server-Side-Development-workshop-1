package com.example.repository

import com.example.model.Category
import com.example.model.CategoryRequest

object CategoryRepository {
    private val categories = mutableListOf<Category>()
    private var nextId = 1

    fun getAll() = categories
    fun getById(id: Int) = categories.find { it.id == id }

    fun add(request: CategoryRequest): Category {
        val category = Category(nextId++, request.name)
        categories.add(category)
        return category
    }

    fun update(id: Int, request: CategoryRequest): Boolean {
        val index = categories.indexOfFirst { it.id == id }
        return if (index != -1) {
            categories[index] = Category(id, request.name)
            true
        } else false
    }

    fun delete(id: Int): Boolean = categories.removeIf { it.id == id }
}
